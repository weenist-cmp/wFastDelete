#ifndef wFastDelete_main_H
#define wFastDelete_main_H


#endif
